
"use client";

import { useEffect, useMemo, useState } from "react";
import { Check, ChevronDown, Search, X } from "lucide-react";
import countries from "i18n-iso-countries";
import enLocale from "i18n-iso-countries/langs/en.json";

countries.registerLocale(enLocale);

type LocationModalProps = {
  isOpen: boolean;
  onClose: () => void;
  selectedCountry: string;
  onSelect: (country: string) => void;
};

const countryNames = Object.values(
  countries.getNames("en", { select: "official" }),
).sort((a, b) => a.localeCompare(b));

export default function LocationModal({
  isOpen,
  onClose,
  selectedCountry,
  onSelect,
}: LocationModalProps) {
  const [search, setSearch] = useState("");
  const [chosenCountry, setChosenCountry] = useState(selectedCountry);

  useEffect(() => {
    if (isOpen) {
      setSearch("");
      setChosenCountry(selectedCountry);
    }
  }, [isOpen, selectedCountry]);

  useEffect(() => {
    if (!isOpen) return;

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") onClose();
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  const filteredCountries = useMemo(() => {
    const query = search.trim().toLocaleLowerCase();

    if (!query) return countryNames;

    return countryNames.filter((country) =>
      country.toLocaleLowerCase().includes(query),
    );
  }, [search]);

  if (!isOpen) return null;

  function handleSubmit() {
    if (!chosenCountry) return;
    onSelect(chosenCountry);
    onClose();
  }

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/50 px-4 py-6 backdrop-blur-[1px]"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="location-modal-title"
        className="relative w-full max-w-[500px] animate-in fade-in zoom-in-95 duration-200 rounded-[3px] bg-white px-[30px] pb-[33px] pt-[27px] shadow-2xl"
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close location dialog"
          className="absolute right-[17px] top-[17px] text-gray-400 transition-colors hover:text-gray-800"
        >
          <X size={19} strokeWidth={1.7} />
        </button>

        <h2
          id="location-modal-title"
          className="text-center text-[23px] font-medium text-[#222]"
        >
          Select Location
        </h2>

        <p className="mt-4 text-center text-sm text-[#999]">
          Filter products by location
        </p>

        <div className="relative mt-[21px]">
          <div className="flex h-[46px] items-center rounded-[3px] border border-[#d9dce2] transition-colors focus-within:border-[#00a99d]">
            <Search
              size={17}
              className="ml-3 shrink-0 text-gray-400"
              aria-hidden="true"
            />

            <input
              type="text"
              value={search}
              onChange={(event) => {
                setSearch(event.target.value);
                setChosenCountry("");
              }}
              placeholder="Search country..."
              aria-label="Search country"
              autoComplete="off"
              className="h-full min-w-0 flex-1 bg-transparent px-3 text-sm text-[#555] outline-none placeholder:text-[#999]"
            />

            <ChevronDown
              size={16}
              className="mr-3 shrink-0 text-gray-400"
              aria-hidden="true"
            />
          </div>

          <div className="mt-2 max-h-[190px] overflow-y-auto rounded-[3px] border border-gray-100 bg-white">
            {filteredCountries.length > 0 ? (
              filteredCountries.map((country) => {
                const isSelected = chosenCountry === country;

                return (
                  <button
                    key={country}
                    type="button"
                    onClick={() => {
                      setChosenCountry(country);
                      setSearch(country);
                    }}
                    className={`flex w-full items-center justify-between px-4 py-2.5 text-left text-sm transition-colors hover:bg-[#f4fbfa] hover:text-[#00a99d] ${
                      isSelected
                        ? "bg-[#f0fbf9] text-[#009e92]"
                        : "text-[#555]"
                    }`}
                  >
                    <span>{country}</span>
                    {isSelected && <Check size={16} />}
                  </button>
                );
              })
            ) : (
              <p className="px-4 py-4 text-center text-sm text-gray-500">
                No countries found
              </p>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={handleSubmit}
          disabled={!chosenCountry}
          className="mt-5 flex h-[46px] w-full items-center justify-center rounded-[3px] bg-[#00a99d] text-sm font-medium text-white transition-all duration-200 hover:bg-[#008f85] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-50"
        >
          Select Location
        </button>
      </section>
    </div>
  );
}
