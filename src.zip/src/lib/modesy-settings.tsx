
"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export type CurrencyCode =
  | "USD"
  | "EUR"
  | "BRL"
  | "GBP"
  | "IDR"
  | "INR"
  | "NGN"
  | "RUB"
  | "TRY";

export type LanguageCode = "en" | "ar";

type ModesySettings = {
  location: string;
  currency: CurrencyCode;
  language: LanguageCode;
  setLocation: (value: string) => void;
  setCurrency: (value: CurrencyCode) => void;
  setLanguage: (value: LanguageCode) => void;
  formatPrice: (amount: number) => string;
  t: (key: string) => string;
};

const currencyOptions: Record<CurrencyCode, string> = {
  USD: "USD",
  EUR: "EUR",
  BRL: "BRL",
  GBP: "GBP",
  IDR: "IDR",
  INR: "INR",
  NGN: "NGN",
  RUB: "RUB",
  TRY: "TRY",
};

const translations: Record<LanguageCode, Record<string, string>> = {
  en: {
    home: "Home",
    products: "Products",
    login: "Login",
    register: "Register",
    search: "Search products...",
    sell: "Sell Now",
    wishlist: "Wishlist",
    cart: "Cart",
    addToCart: "Add to Cart",
    viewAll: "View all products",
    location: "Location",
    featuredProducts: "Featured Products",
    specialOffers: "Special Offers",
    loadMore: "Load More",
    quote: "Contact for price",
    free: "Free",
  },
  ar: {
    home: "الرئيسية",
    products: "المنتجات",
    login: "تسجيل الدخول",
    register: "إنشاء حساب",
    search: "ابحث عن المنتجات...",
    sell: "بع الآن",
    wishlist: "المفضلة",
    cart: "سلة التسوق",
    addToCart: "أضف إلى السلة",
    viewAll: "عرض جميع المنتجات",
    location: "الموقع",
    featuredProducts: "المنتجات المميزة",
    specialOffers: "عروض خاصة",
    loadMore: "عرض المزيد",
    quote: "تواصل لمعرفة السعر",
    free: "مجاني",
  },
};

const LOCATION_KEY = "modesy-location";
const CURRENCY_KEY = "modesy-currency";
const LANGUAGE_KEY = "modesy-language";

function isCurrencyCode(value: string): value is CurrencyCode {
  return Object.prototype.hasOwnProperty.call(currencyOptions, value);
}

function readSavedCurrency(value: string | null): CurrencyCode | null {
  if (!value) return null;

  const code = value.trim().split(/\s+/)[0].toUpperCase();

  return isCurrencyCode(code) ? code : null;
}

function readSavedLanguage(value: string | null): LanguageCode {
  // Mendukung pilihan Arabic yang baru.
  if (value === "ar") return "ar";

  // Pilihan lama Indonesia dialihkan ke English.
  return "en";
}

const SettingsContext = createContext<ModesySettings | null>(null);

export function ModesySettingsProvider({
  children,
}: {
  children: ReactNode;
}) {
  const [location, setLocationState] = useState("Indonesia");
  const [currency, setCurrencyState] = useState<CurrencyCode>("USD");
  const [language, setLanguageState] = useState<LanguageCode>("en");

  useEffect(() => {
    try {
      const savedLocation = localStorage.getItem(LOCATION_KEY);
      const savedCurrency = readSavedCurrency(
        localStorage.getItem(CURRENCY_KEY),
      );
      const savedLanguage = readSavedLanguage(
        localStorage.getItem(LANGUAGE_KEY),
      );

      if (savedLocation) setLocationState(savedLocation);
      if (savedCurrency) setCurrencyState(savedCurrency);

      setLanguageState(savedLanguage);
      document.documentElement.lang = savedLanguage;
      document.documentElement.dir =
        savedLanguage === "ar" ? "rtl" : "ltr";
    } catch {
      // Gunakan pengaturan default jika localStorage tidak tersedia.
    }
  }, []);

  const setLocation = useCallback((value: string) => {
    setLocationState(value);

    try {
      localStorage.setItem(LOCATION_KEY, value);
    } catch {
      // Pilihan tetap berlaku selama halaman terbuka.
    }
  }, []);

  const setCurrency = useCallback((value: CurrencyCode) => {
    if (!isCurrencyCode(value)) return;

    setCurrencyState(value);

    try {
      localStorage.setItem(CURRENCY_KEY, value);
    } catch {
      // Pilihan tetap berlaku selama halaman terbuka.
    }
  }, []);

  const setLanguage = useCallback((value: LanguageCode) => {
    if (value !== "en" && value !== "ar") return;

    setLanguageState(value);
    document.documentElement.lang = value;
    document.documentElement.dir = value === "ar" ? "rtl" : "ltr";

    try {
      localStorage.setItem(LANGUAGE_KEY, value);
    } catch {
      // Pilihan tetap berlaku selama halaman terbuka.
    }
  }, []);

  const formatPrice = useCallback(
    (amount: number) => {
      if (!Number.isFinite(amount)) return "";

      if (currency === "IDR") {
        return new Intl.NumberFormat("id-ID", {
          style: "currency",
          currency: "IDR",
          maximumFractionDigits: 0,
        })
          .format(amount)
          .replace(/\s/g, "");
      }

      return new Intl.NumberFormat(
        language === "ar" ? "ar-SA" : "en-US",
        {
          style: "currency",
          currency,
          maximumFractionDigits: 2,
        },
      ).format(amount);
    },
    [currency, language],
  );

  const t = useCallback(
    (key: string) => translations[language][key] ?? key,
    [language],
  );

  const value = useMemo<ModesySettings>(
    () => ({
      location,
      currency,
      language,
      setLocation,
      setCurrency,
      setLanguage,
      formatPrice,
      t,
    }),
    [
      location,
      currency,
      language,
      setLocation,
      setCurrency,
      setLanguage,
      formatPrice,
      t,
    ],
  );

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useModesySettings() {
  const context = useContext(SettingsContext);

  if (!context) {
    throw new Error(
      "useModesySettings harus digunakan di dalam ModesySettingsProvider.",
    );
  }

  return context;
}
